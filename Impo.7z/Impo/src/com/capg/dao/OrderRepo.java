package com.capg.dao;

import com.capg.model.Product;

public interface OrderRepo {
	int saveOrder(Product pro);

}
