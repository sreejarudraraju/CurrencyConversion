package com.capg.ser;

import com.capg.model.Product;

public interface OrderService {
	int calculateOrder(Product p);

}
